<footer class="footer">
    <p class="m-0 text-center text-white">Informacje o sklepie (adres, zwroty, kontakt)</p>
</footer>
