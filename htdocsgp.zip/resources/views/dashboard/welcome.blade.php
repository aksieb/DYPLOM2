@extends('dashboard/template')

@section('right_box')
    <div class='row'>
        <div class='col-sm-12'>
            <h4>Witaj administratorze</h4>
            Rób swoje, dziel i rządz
        </div>
    </div>
@endsection
