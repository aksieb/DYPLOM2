<?php

namespace App\Contants;

class Main {

    const UNITS = array(
        'złotych', 'sztuk', 'litrów', 'kilogramów', 'gramów', 'metrów'
    );

    const DEFAULT_ATTRIBUTES = array(
        array(
            'key'   => 'price',
            'name'  => 'Cena',
            'value' => ''
        )
    );
}
