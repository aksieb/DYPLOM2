<?php $__env->startSection('right_box'); ?>
    <div class='row'>
        <div class='col-sm-12'>
            <nav aria-label="breadcrumb mb-2">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href=<?php echo e(url('/dashboard')); ?>>Panel</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Produkty</li>
                </ol>
            </nav>

            <a href=<?php echo e(url('/dashboard/product')); ?> class='btn btn-primary mb-3'>Dodaj</a>

            <?php if(session('success')): ?>
                <div class="alert alert-success mb-3">
                    <?php echo e(session('success_msg')); ?>

                </div>
            <?php endif; ?>

            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nazwa</th>
                        <th scope="col">Kategoria</th>
                        <th scope="col">Dostępna ilość</th>
                        <th scope="col">Akcje</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <th scope="row"><?php echo e($product->id); ?></th>
                            <td><?php echo e($product->name); ?></td>
                            <td><?php echo e($product->category->name); ?></td>
                            <td><?php echo e($product->quantity); ?></td>
                            <td>
                                <a
                                    href=<?php echo e(url('/dashboard/product/' . $product->id)); ?>

                                    class='btn btn-primary'
                                >Edytuj</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <th scope='row' colspan='5' class='text-center'>Brak rekordów</th>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <?php echo e($products->appends(array(

            ))->links('pagination::bootstrap-4')); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH S:\courses\kasia_beska\a4\resources\views/dashboard/products/index.blade.php ENDPATH**/ ?>