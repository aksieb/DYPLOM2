<?php $__env->startSection('right_box'); ?>
    <div class='row'>
        <div class='col-sm-12'>
            <nav aria-label="breadcrumb mb-2">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href=<?php echo e(url('/dashboard')); ?>>Panel</a></li>
                    <li class="breadcrumb-item"><a href=<?php echo e(url('/dashboard/products')); ?>>Produkty</a></li>
                    <?php if(isset($product)): ?>
                        <li class="breadcrumb-item active" aria-current="page"><?php echo e($product->id); ?></li>
                    <?php else: ?>
                        <li class="breadcrumb-item active" aria-current="page">Dodaj</li>
                    <?php endif; ?>
                </ol>
            </nav>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger mt-4">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form class='mt-4' method='post' enctype='multipart/form-data'>
                <?php echo csrf_field(); ?>

                <div class='row'>
                    <div class='col-sm-6'>
                        <div class='form-group'>
                            <label for='name'>Nazwa produktu</label>
                            <input
                                type='text'
                                id='name'
                                name='name'
                                required='required'
                                class='form-control'
                                value="<?php echo e(isset($product) ? $product->name : ""); ?>"
                            />
                        </div>

                        <div class='form-group'>
                            <label for='description'>Opis produktu</label>
                            <textarea
                                class="form-control"
                                id="description"
                                name="description" rows="5"
                            ><?php echo e(isset($product) ? $product->description : ""); ?></textarea>
                        </div>

                        <div class='form-group'>
                            <label for='name'>Dostępne</label>
                            <div class='d-flex'>
                                <input
                                    type='number'
                                    step="0.01"
                                    min="0"
                                    id='quantity'
                                    name='quantity'
                                    required='required'
                                    class='form-control'
                                    value="<?php echo e(isset($product) ? $product->quantity : ""); ?>"
                                />

                                <select
                                    id='unit'
                                    name='unit'
                                    required='required'
                                    class='form-control'
                                >
                                    <?php $__currentLoopData = $attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option
                                            value=<?php echo e($attr->id); ?>

                                            <?php if(isset($product)): ?> <?php if($attr->id == $product->unit): ?> selected='selected' <?php endif; ?> <?php endif; ?>
                                        ><?php echo e($attr->name); ?> (<?php echo e($units[$attr->unit]); ?>)</option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <div class='form-group'>
                            <label for='name'>Kategoria</label>
                            <select
                                id='category_id'
                                name='category_id'
                                required='required'
                                class='form-control'
                            >
                                <option>Wybierz</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                        value=<?php echo e($category->id); ?>

                                        <?php echo e((isset($product) && $product->category_id == $category->id) || $categoryId == $category->id ? "selected='selected'" : ""); ?>

                                    ><?php echo e($category->name); ?></option>
                                    <?php $__currentLoopData = $category->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option
                                            value=<?php echo e($cat->id); ?>

                                            <?php echo e((isset($product) && $product->category_id == $cat->id) || $categoryId == $cat->id ? "selected='selected'" : ""); ?>

                                        >&nbsp;&nbsp;&nbsp;&nbsp;<?php echo e($cat->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>


                        <div class='form-group'>
                            <label for='files'>Pliki</label>
                            <input
                                type='file'
                                multiple="multiple"
                                accept="image/*"
                                id='files[]'
                                name='files[]'
                                class='form-control-file'
                            />

                            <?php if(isset($product)): ?>
                                <table class='table mt-4'>
                                    <thead>
                                        <tr>
                                            <th scope='col'>ID</th>
                                            <th scope='col'>Nazwa</th>
                                            <th scope='col'>Podgląd</th>
                                            <th scope='col'>Akcje</th>
                                        </tr>
                                    </thead>

                                    <tbody class='files'>
                                        <?php $__currentLoopData = $product->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr class='file-row'>
                                                <td><?php echo e($key + 1); ?></td>
                                                <td><?php echo e($file->filename_original); ?></td>
                                                <td>
                                                    <img
                                                        src=<?php echo e(url($file->filename)); ?>

                                                        alt=<?php echo e($file->filename_original); ?>

                                                        width="120px"
                                                    />
                                                </td>
                                                <td>
                                                    <button
                                                        type='button'
                                                        class='btn btn-danger file-delete'
                                                        data-id=<?php echo e($file->id); ?>

                                                    >Usuń</button>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class='col-sm-6'>
                        <h6>Atrybuty</h6>
                        <small>Dodaj atrybuty produktu</small>

                        <div id="attributes" class='mt-2'>
                            <button id="add_attribute" type='button' class='btn btn-primary mb-2'>Dodaj</button>

                            <?php if(isset($product)): ?>
                                <?php $__currentLoopData = $product->productAttributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class='row m-1 attribute_row'>
                                        <div class='col-sm-4'>
                                            <?php echo $__env->make('dashboard.products.attribute', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div>

                                        <div class='col-sm-3'>
                                            <div class='form-group'>
                                                <label for='name'>Wartość</label>
                                                <input
                                                    type='text'
                                                    name="values[]"
                                                    class='form-control'
                                                    value=<?php echo e($attribute->value); ?>

                                                >
                                            </div>
                                        </div>

                                        <div class='col-sm-3'>
                                            <div class='form-group'>
                                                <label for='name'>Jednostka</label>
                                                <div class='unit'><?php echo e($units[$attribute->attribute->unit]); ?></div>
                                            </div>
                                        </div>

                                        <div class='col-sm-1 d-flex'>
                                            <button
                                                type="button"
                                                class='btn btn-danger attribute_delete'
                                            >Usuń</button>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>

                        <template id="attribute_template">
                            <div class='row m-1 attribute_row'>
                                <div class='col-sm-4'>
                                    <?php echo $__env->make('dashboard.products.attribute', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>

                                <div class='col-sm-3'>
                                    <div class='form-group'>
                                        <label for='name'>Wartość</label>
                                        <input
                                            type='text'
                                            name="values[]"
                                            class='form-control'
                                        >
                                    </div>
                                </div>

                                <div class='col-sm-3'>
                                    <div class='form-group'>
                                        <label for='name'>Jednostka</label>
                                        <div class='unit'></div>
                                    </div>
                                </div>

                                <div class='col-sm-1 d-flex'>
                                    <button
                                        type="button"
                                        class='btn btn-danger attribute_delete'
                                    >Usuń</button>
                                </div>
                            </div>
                        </template>
                    </div>
                </div>

                <div class="d-flex flex-column justify-content-center text-center">
                    <button class="btn btn-primary mt-3 mx-auto" type="submit">Zapisz</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        var units = <?php echo json_encode($units, 15, 512) ?>;
        var attributes = <?php echo json_encode($attributes, 15, 512) ?>;
        var defaultUnit = units[attributes[0].unit];

        $('#add_attribute').on('click', function() {
            if($('#attributes').children().length > attributes.length) {
                return;
            }

            var template = $('#attribute_template').clone();
            var node = template.prop('content');
            var unit = $(node).find('.unit');
            $(unit).html(defaultUnit);

            $('#attributes').append(template.html());
        });

        $(document).on('click', '.attribute-choose', function() {
            var unit = $(this).closest('.attribute_row').find('.unit');
            var id = $("option:selected", this).data('unit');

            console.log(unit);

            $(unit).html(units[id]);
        });

        $('.file-delete').on('click', function() {
            var id = $(this).data('id');

            fetch('/files', {
                method: 'DELETE',
                credentials: 'include',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    id,
                    _token: '<?php echo e(csrf_token()); ?>'
                })
            })
            .then(response => response.json())
            .then(data => {
                $(this).closest('.file-row').remove();
            });
        });

        $(document).on('click', '.attribute_delete', function() {
            var row = $(this).closest('.attribute_row');
            $(row).remove();
        });

        $('.record-delete').on('click', function() {
            return confirm("Jesteś pewien? Usunięte zostaną wszystkie dane kursu!");
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resources\views/dashboard/products/form.blade.php ENDPATH**/ ?>