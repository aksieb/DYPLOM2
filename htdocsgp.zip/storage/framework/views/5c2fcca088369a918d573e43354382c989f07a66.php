<footer class="footer">
    <p class="m-0 text-center text-white">Informacje o sklepie (adres, zwroty, kontakt)</p>
</footer>
<?php /**PATH C:\xampp\htdocs\resources\views/front/components/footer.blade.php ENDPATH**/ ?>