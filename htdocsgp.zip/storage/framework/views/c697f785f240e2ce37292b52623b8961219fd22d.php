<?php $__env->startSection('right_box'); ?>
    <div class='row'>
        <div class='col-sm-12'>
            <h4>Witaj administratorze</h4>
            Rób swoje, dziel i rządz
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH S:\courses\kasia_beska\a4\resources\views/dashboard/welcome.blade.php ENDPATH**/ ?>