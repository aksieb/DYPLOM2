<?php $__env->startSection('stylesheets'); ?>
    <link rel='stylesheet' href=<?php echo e(asset('/assets/css/shop-item.css')); ?> />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('front.components.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container">
        <div class="row">
            <?php echo $__env->make('front.components.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php
                $fullprice = 0;
            ?>

            <div class="col-lg-9 mt-5">
                <section>
                    <div class="row">
                        <div class="col-lg-8">
                            <div class="card wish-list mb-3">
                                <div class="card-body">
                                    <h5 class="mb-4">Koszyk (<span><?php echo e($count); ?></span> przedmiotów)</h5>

                                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <?php
                                            $cost = $cart[$product->id] * $product->price();
                                            $fullprice += $cost;
                                        ?>

                                        <div class="row mb-4">
                                            <div class="col-md-5 col-lg-3 col-xl-3">
                                                <div id="carouselControls" class="carousel slide" data-ride="carousel">
                                                    <div class="carousel-inner">
                                                        <?php $__currentLoopData = $product->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="carousel-item active">
                                                                <img class="d-block w-100" src=<?php echo e(url($file->filename)); ?> alt="Zdjęcie produktu">
                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>

                                                    <a class="carousel-control-prev" href="#carouselControls" role="button" data-slide="prev">
                                                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                                        <span class="sr-only">Poprzedni</span>
                                                    </a>

                                                    <a class="carousel-control-next" href="#carouselControls" role="button" data-slide="next">
                                                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                                        <span class="sr-only">Następny</span>
                                                    </a>
                                                </div>
                                            </div>

                                            <div class="col-md-7 col-lg-9 col-xl-9">
                                                <div class="d-flex justify-content-between">
                                                    <div>
                                                        <h5><?php echo e($product->name); ?></h5>
                                                        <p class="mb-3 text-muted text-uppercase small">Kategoria: <?php echo e($product->category->name); ?></p>
                                                    </div>

                                                    <div>
                                                        <div class="def-number-input number-input safari_only mb-0 w-100 d-flex">
                                                            <button
                                                                type="button"
                                                                onclick="this.parentNode.querySelector('input[type=number]').stepDown()"
                                                                class="minus">-</button>

                                                            <input class="quantity" min="0" name="quantity" value=<?php echo e($cart[$product->id]); ?> type="number">

                                                            <button
                                                                type="button"
                                                                onclick="this.parentNode.querySelector('input[type=number]').stepUp()"
                                                                class="plus">+</button>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="d-flex justify-content-between align-items-center">
                                                    <div>
                                                        <a
                                                            href=<?php echo e(url('/deleteFromCart/' . $product->id)); ?>

                                                            type="button"
                                                            class="card-link-secondary small text-uppercase mr-3">
                                                            <i class="fas fa-trash-alt mr-1"></i> Usuń produkt
                                                        </a>
                                                    </div>

                                                    <p class="mb-0"><span><strong><?php echo e($cart[$product->id]); ?>x<?php echo e($product->price()); ?>zł = <?php echo e($cost); ?> zł</strong></span></p>
                                                </div>

                                                <hr class="mb-4">
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <div class="row mb-4">
                                            <div class="col-sm-12">
                                                <div class="d-flex justify-content-between">
                                                    Brak przedmiotów w koszyku
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>

                                    <p class="text-primary mb-4">
                                        <i class="fas fa-info-circle mr-1"></i>
                                        Dodanie produktu do koszyka nie powoduje rezerwacji produktu.
                                    </p>
                                </div>
                            </div>

                            <div class="card mb-3">
                                <div class="card-body">
                                    <h5 class="mb-4">Oczekiwany czas dostawy</h5>

                                    <p class="mb-0"> Do 10 dni roboczych</p>
                                </div>
                            </div>

                            <div class="card mb-3">
                                <div class="card-body">

                                    <h5 class="mb-4">Akceptujemy płatności</h5>

                                    <img class="mr-2" width="45px"
                                        src="https://mdbootstrap.com/wp-content/plugins/woocommerce-gateway-stripe/assets/images/visa.svg"
                                        alt="Visa">
                                    <img class="mr-2" width="45px"
                                        src="https://mdbootstrap.com/wp-content/plugins/woocommerce-gateway-stripe/assets/images/amex.svg"
                                        alt="American Express">
                                    <img class="mr-2" width="45px"
                                        src="https://mdbootstrap.com/wp-content/plugins/woocommerce-gateway-stripe/assets/images/mastercard.svg"
                                        alt="Mastercard">

                                </div>
                            </div>
                        </div>

                        <div class="col-lg-4">
                            <div class="card mb-3">
                                <div class="card-body">

                                    <h5 class="mb-3">Podsumowanie</h5>

                                    <ul class="list-group list-group-flush">
                                        <li
                                            class="list-group-item d-flex justify-content-between align-items-center border-0 px-0 pb-0">
                                            Cena produktów
                                            <span><?php echo e($fullprice); ?> zł</span>
                                        </li>
                                        <li class="list-group-item d-flex justify-content-between align-items-center px-0">
                                            Dostawa
                                            <span>Gratis</span>
                                        </li>
                                        <li
                                            class="list-group-item d-flex justify-content-between align-items-center border-0 px-0 mb-3">
                                            <div>
                                                <strong>Cena zamówienia</strong>

                                            </div>
                                            <span><strong><?php echo e($fullprice); ?> zł</strong></span>
                                        </li>
                                    </ul>

                                    <a
                                        href=<?php echo e(url('/order')); ?>

                                        class="btn btn-primary btn-block waves-effect waves-light"
                                    >Zamawiam</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH S:\courses\kasia_beska\a4\resources\views/front/cart.blade.php ENDPATH**/ ?>