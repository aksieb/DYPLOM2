<footer class="footer">
    <p class="m-0 text-center text-white">Informacje o sklepie (adres, zwroty, kontakt)</p>
</footer>
<?php /**PATH S:\courses\kasia_beska\a4\resources\views/front/components/footer.blade.php ENDPATH**/ ?>