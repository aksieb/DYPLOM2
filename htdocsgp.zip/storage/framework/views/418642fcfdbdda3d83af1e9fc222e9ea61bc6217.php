<?php $__env->startSection('stylesheets'); ?>
    <link rel='stylesheet' href=<?php echo e(asset('/assets/css/shop-item.css')); ?> />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('front.components.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container">
        <div class="row">
            <?php echo $__env->make('front.components.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="col-lg-9 mt-5">
                <section class="mb-5">
                    <div class="row">
                        <div class="col-md-6 mb-4 mb-md-0">
                            <div id="carouselControls" class="carousel slide" data-ride="carousel">
                                <div class="carousel-inner">
                                    <?php $__currentLoopData = $product->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="carousel-item active">
                                            <img class="d-block w-100" src=<?php echo e(url($file->filename)); ?> alt="Zdjęcie produktu">
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>

                                <a class="carousel-control-prev" href="#carouselControls" role="button" data-slide="prev">
                                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                    <span class="sr-only">Poprzedni</span>
                                </a>

                                <a class="carousel-control-next" href="#carouselControls" role="button" data-slide="next">
                                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                    <span class="sr-only">Następny</span>
                                </a>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="opis">

                                <h5><strong><?php echo e($product->name); ?></strong></h5>
                                <p class="mb-2 text-muted text-uppercase small"><?php echo e($product->category->name); ?></p>

                                <p><span class="mr-1"><strong><?php echo e($product->price()); ?> zł</strong></span></p>
                                <p class="pt-1"><?php echo e($product->description); ?></p>
                                <div class="table-responsive">
                                    <table class="table table-sm table-borderless mb-0">
                                        <tbody>
                                            <?php $__currentLoopData = $product->attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($attribute->key != 'price'): ?>
                                                    <tr>
                                                        <th class="pl-0 w-25" scope="row"><strong><?php echo e($attribute->name); ?></strong></th>
                                                        <td><?php echo e($attribute->pivot->value); ?> <?php echo e($units[$attribute->unit]); ?></td>
                                                    </tr>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>

                                <hr>

                                <form method='POST' action=<?php echo e(url('addToCart')); ?>>
                                    <?php echo csrf_field(); ?>

                                    <input type='hidden' name='product_id' value=<?php echo e($product->id); ?> />

                                    <div class="table-responsive mb-2">
                                        <table class="table table-sm table-borderless">
                                            <tbody>
                                                <tr>
                                                    <td class="pl-0 pb-0 w-25"><strong>ILOŚĆ</strong></td>
                                                </tr>
                                                <tr>
                                                    <td class="pl-0">
                                                        <div class="def-number-input number-input safari_only mb-0">
                                                            <button
                                                                type='button'
                                                                onclick="this.parentNode.querySelector('input[type=number]').stepDown()"
                                                            >-</button>
                                                            <input class="quantity" min="0" name='quantity' value="1"
                                                                type="number">
                                                            <button
                                                                type='button'
                                                                onclick="this.parentNode.querySelector('input[type=number]').stepUp()"
                                                            >+</button>
                                                        </div>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>

                                    <?php if($product->existsInCart()): ?>
                                        Czeka w koszyku
                                    <?php else: ?>
                                        <button type="submit" class="btn btn-light btn-md mr-1 mb-2">
                                            <i class="fas fa-shopping-cart pr-2"></i>Dodaj do koszyka
                                        </button>
                                    <?php endif; ?>
                                </form>
                            </div>
                        </div>
                    </div>

                </section>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH S:\courses\kasia_beska\a4\resources\views/front/product.blade.php ENDPATH**/ ?>