<?php $__env->startSection('right_box'); ?>
    <div class='row'>
        <div class='col-sm-12'>
            <h4>Konfiguracja</h4>

            <form method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div class='form-group'>
                    <label>Logo</label>
                    <input
                        type='file'
                        name='logo'
                        class='form-control-file'
                    />
                </div>

                <button type='submit' class='btn btn-primary'>Zapisz</button>
            </form>

            <?php if(isset($logo)): ?>
                <div class='row mt-4'>
                    <div class='col-sm-6'>
                        <h5>Aktualne logo</h5>
                        <img src=<?php echo e(url($logo->filename)); ?> width="300px" alt="Logo" />
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resources\views/dashboard/configuration.blade.php ENDPATH**/ ?>