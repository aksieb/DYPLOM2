<!DOCTYPE html>
<html lang="pl">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Panel administracyjny</title>

    <link rel='stylesheet' href=<?php echo e(asset('/assets/css/bootstrap.min.css')); ?> />
    <link rel='stylesheet' href=<?php echo e(asset('/assets/css/app.css')); ?> />
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href=<?php echo e(url('/dashboard')); ?>>Panel administracyjny</a>
    </nav>

    <div class="wrapper">
        <nav class="sidebar">
            <?php echo $__env->make('dashboard/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </nav>

        <div class="container content-box">
            <?php echo $__env->yieldContent('right_box'); ?>
        </div>
    </div>

    <script src=<?php echo e(asset('/assets/js/jquery.min.js')); ?>></script>
    <script src=<?php echo e(asset('/assets/js/popper.min.js')); ?>></script>
    <script src=<?php echo e(asset('/assets/js/bootstrap.bundle.min.js')); ?>></script>

    <?php echo $__env->yieldContent('scripts'); ?>
</body>

</html>
<?php /**PATH S:\courses\kasia_beska\a4\resources\views/dashboard/template.blade.php ENDPATH**/ ?>