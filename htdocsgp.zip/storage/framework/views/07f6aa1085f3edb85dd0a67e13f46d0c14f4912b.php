<?php $__env->startSection('right_box'); ?>
    <div class='row'>
        <div class='col-sm-12'>
            <nav aria-label="breadcrumb mb-2">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href=<?php echo e(url('/dashboard')); ?>>Panel</a></li>
                    <li class="breadcrumb-item" aria-current="page"><a href=<?php echo e(url('/dashboard/categories')); ?>>Kategorie</a>
                    </li>

                    <?php if(isset($categoryId)): ?>
                        <li class="breadcrumb-item" aria-current="page"><a
                                href=<?php echo e(url('/dashboard/categories/' . $categoryId)); ?>><?php echo e($categoryId); ?></a></li>
                    <?php endif; ?>

                    <?php if(isset($category)): ?>
                        <li class="breadcrumb-item active" aria-current="page"><?php echo e($category->id); ?></li>
                    <?php else: ?>
                        <li class="breadcrumb-item active" aria-current="page">Dodaj</li>
                    <?php endif; ?>
                </ol>
            </nav>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger mt-4">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form class='mt-4' method='post'>
                <?php echo csrf_field(); ?>

                <div class='row'>
                    <div class='col-sm-6'>
                        <div class='form-group'>
                            <label for='name'>Nazwa kategorii</label>
                            <input type='text' id='name' name='name' required='required' class='form-control'
                                value="<?php echo e(isset($category) ? $category->name : ''); ?>" />
                        </div>

                        <div class='form-group'>
                            <label for='description'>Opis kategorii</label>
                            <textarea class="form-control" id="description" name="description" rows="5"></textarea>
                        </div>
                    </div>

                    <div class='col-sm-6'>
                        <div class='form-group'>
                            <label for='name'>Kategoria nadrzędna</label>
                            <select id='category_id' name='category_id' class='form-control'>
                                <option value="">Wybierz</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value=<?php echo e($catm->id); ?>

                                        <?php echo e(isset($category) && $category->category_id == $catm->id ? "selected='selected'" : ''); ?>>
                                        <?php echo e($catm->name); ?>

                                    </option>
                                    <?php $__currentLoopData = $catm->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value=<?php echo e($cat->id); ?>

                                            <?php echo e(isset($category) && $category->category_id == $cat->id ? "selected='selected'" : ''); ?>>
                                            &nbsp;&nbsp;&nbsp;&nbsp;<?php echo e($cat->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="mt-3 d-flex justify-content-center">
                    <?php if(isset($category)): ?>
                        <a href=<?php echo e(url('/dashboard/category-products/' . $category->id)); ?>

                            class='btn btn-primary ml-1'>Produkty</a>
                    <?php endif; ?>

                    <button class="btn btn-primary <?php if(isset($category)): ?> ml-1 <?php endif; ?>" type="submit">Zapisz</button>

                    <?php if(isset($category)): ?>
                        <a href=<?php echo e(url('/dashboard/category/' . $category->id . '/delete')); ?>

                            class='btn btn-danger ml-1 record-delete'>Usuń</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resources\views/dashboard/categories/form.blade.php ENDPATH**/ ?>