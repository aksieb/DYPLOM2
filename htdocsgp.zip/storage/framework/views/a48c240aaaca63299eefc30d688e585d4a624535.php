<?php $__env->startSection('stylesheets'); ?>
    <link rel='stylesheet' href=<?php echo e(asset('/assets/css/shop-item.css')); ?> />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('front.components.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container">
        <div class="row">
            <?php echo $__env->make('front.components.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="col-lg-9">
                <div class="carda">
                    <section class="text-center mb-4">
                        <div class="row wow fadeIn">
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-3 col-md-6 mb-4 mt-4">
                                    <div class="card product-card">
                                        <div class='card-img-box'>
                                            <?php $__currentLoopData = $product->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <img src=<?php echo e(url($file->filename)); ?> class="card-img-top" alt="">
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>

                                        <div class="card-body text-center">
                                            <a href=<?php echo e(url('/product/' . $product->id)); ?> class="grey-text">
                                                <h5><strong><?php echo e($product->name); ?></strong></h5>
                                            </a>

                                            <h5>
                                                <form method='POST' action=<?php echo e(url('addToCart')); ?>>
                                                    <?php echo csrf_field(); ?>

                                                    <input type='hidden' name='product_id' value=<?php echo e($product->id); ?> />
                                                    <input type='hidden' name='quantity' value='1' />

                                                    <?php if($product->existsInCart()): ?>
                                                        <small>Czeka w koszyku</small>
                                                    <?php else: ?>
                                                        <button type="submit" class="btn btn-secondary btn-sm">Do koszyka</button>
                                                    <?php endif; ?>
                                                </form>
                                            </h5>

                                            <h4 class="font-weight-bold blue-text">
                                                <strong><?php echo e($product->price()); ?>zł</strong>
                                            </h4>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </section>
                </div>

                <?php echo e($products->appends([])->links('pagination::bootstrap-4')); ?>

            </div>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH S:\courses\kasia_beska\a4\resources\views/front/category.blade.php ENDPATH**/ ?>