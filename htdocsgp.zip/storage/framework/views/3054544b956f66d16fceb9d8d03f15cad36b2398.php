<?php $__env->startSection('right_box'); ?>
    <div class='row'>
        <div class='col-sm-12'>
            <nav aria-label="breadcrumb mb-2">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href=<?php echo e(url('/dashboard')); ?>>Panel</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Zamówienia</li>
                </ol>
            </nav>

            <?php if(session('success')): ?>
                <div class="alert alert-success mb-3">
                    <?php echo e(session('success_msg')); ?>

                </div>
            <?php endif; ?>

            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Utworzono</th>
                        <th scope="col">Zaktualizowano</th>
                        <th scope="col">Zakończono</th>
                        <th scope="col">Anulowano</th>
                        <th scope="col">Akcje</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <th scope="row"><?php echo e($order->id); ?></th>
                            <td><?php echo e($order->created_at ? date('d.m.Y H:i', strtotime($order->created_at)) : 'Brak'); ?></td>
                            <td><?php echo e($order->updated_at ? date('d.m.Y H:i', strtotime($order->updated_at)) : 'Brak'); ?></td>
                            <td><?php echo e($order->finished_at ? date('d.m.Y H:i', strtotime($order->finished_at)) : 'Brak'); ?></td>
                            <td><?php echo e($order->cancelled_at ? date('d.m.Y H:i', strtotime($order->cancelled_at)) : 'Brak'); ?></td>
                            <td>
                                <a href=<?php echo e(url('/dashboard/order/' . $order->id)); ?> class='btn btn-primary'>Pokaż</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <th scope='row' colspan='6' class='text-center'>Brak rekordów</th>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <?php echo e($orders->appends([])->links('pagination::bootstrap-4')); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH S:\courses\kasia_beska\a4\resources\views/dashboard/orders/index.blade.php ENDPATH**/ ?>