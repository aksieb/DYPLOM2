<?php $__env->startSection('stylesheets'); ?>
    <link rel='stylesheet' href=<?php echo e(asset('/assets/css/shop-item.css')); ?> />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('front.components.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container">
        <div class="row">
            <?php echo $__env->make('front.components.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="col-lg-9 mt-5">
                <div class='row'>
                    <div class='col-sm-6'>
                        <h2>Daty</h2>
                        <p>
                            <b>Utworzono:</b> <?php echo e($order->created_at ? date('d.m.Y H:i', strtotime($order->created_at)) : 'Brak'); ?>

                        </p>
                        <p>
                            <b>Zaktualizowano:</b> <?php echo e($order->updated_at ? date('d.m.Y H:i', strtotime($order->updated_at)) : 'Brak'); ?>

                        </p>
                        <p>
                            <b>Zakończono:</b> <?php echo e($order->finished_at ? date('d.m.Y H:i', strtotime($order->finished_at)) : 'Brak'); ?>

                        </p>
                        <p>
                            <b>Anulowano:</b> <?php echo e($order->cancelled_at ? date('d.m.Y H:i', strtotime($order->cancelled_at)) : 'Brak'); ?>

                        </p>
                    </div>

                    <div class='col-sm-6'>
                        <h2>Klient</h2>
                        <p>
                            <b>Imię:</b> <?php echo e($order->data->first_name); ?>

                        </p>
                        <p>
                            <b>Nazwisko:</b> <?php echo e($order->data->last_name); ?>

                        </p>
                        <p>
                            <b>Telefon:</b> <?php echo e($order->data->phone); ?>

                        </p>
                        <p>
                            <b>Email:</b> <?php echo e($order->data->email); ?>

                        </p>
                        <p>
                            <b>Adres:</b><br />
                            <?php echo e($order->data->street); ?> <?php echo e($order->data->house_number); ?><?php echo e($order->data->apartment_number ? '/' . $order->data->apartment_number : ''); ?><br />
                            <?php echo e($order->data->zipcode); ?> <?php echo e($order->data->city); ?><br />
                            <?php echo e($order->data->country); ?>

                        </p>
                    </div>
                </div>

                <div class='row'>
                    <div class='col-sm-12'>
                        <h2>Produkty</h2>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Nazwa</th>
                                    <th scope="col">Kategoria</th>
                                    <th scope="col">Ilość</th>
                                    <th scope="col">Cena jednostkowa</th>
                                    <th scope="col">Cena</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php $total = 0; ?>

                                <?php $__empty_1 = true; $__currentLoopData = $order->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php
                                        $price = $product->price();
                                        $multiply = $product->pivot->quantity * $price;
                                        $total += $multiply;
                                    ?>

                                    <tr>
                                        <th scope="row"><?php echo e($product->id); ?></th>
                                        <td><?php echo e($product->name); ?></td>
                                        <td><?php echo e($product->category->name); ?></td>
                                        <td><?php echo e($product->pivot->quantity); ?></td>
                                        <td><?php echo e($price); ?> złotych</td>
                                        <td><?php echo e($multiply); ?> złotych</td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <th scope='row' colspan='5' class='text-center'>Brak rekordów</th>
                                    </tr>
                                <?php endif; ?>

                                <tr>
                                    <th scope='row' colspan='5' class='text-right'>Razem:</th>
                                    <td><?php echo e($total); ?> złotych</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resources\views/front/summary.blade.php ENDPATH**/ ?>