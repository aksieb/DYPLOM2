<div class="col-lg-3">
    <h1 class="my-4">Spożywczak</h1>
    <div class="list-group">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p>
                <a class="btn btn-link" data-toggle="collapse" href=<?php echo e('#category-' . $key); ?> role="button"
                    aria-expanded="false" aria-controls=<?php echo e('category-' . $key); ?>>
                    <?php echo e($category->name); ?>

                </a>
            </p>
            <div class="collapse" id=<?php echo e('category-' . $key); ?>>
                <ul>
                    <?php $__currentLoopData = $category->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(url('/category/' . $subcategory->id)); ?>"><?php echo e($subcategory->name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\resources\views/front/components/menu.blade.php ENDPATH**/ ?>