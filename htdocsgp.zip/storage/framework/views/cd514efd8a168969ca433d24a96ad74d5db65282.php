<?php $__env->startSection('right_box'); ?>
    <div class='row'>
        <div class='col-sm-12'>
            <nav aria-label="breadcrumb mb-2">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href=<?php echo e(url('/dashboard')); ?>>Panel</a></li>
                    <li class="breadcrumb-item active">Atrybuty</li>
                </ol>
            </nav>

            <a href=<?php echo e(url('/dashboard/attribute')); ?> class='btn btn-primary mb-3'>Dodaj</a>

            <?php if(session('success')): ?>
                <div class="alert alert-success mb-3">
                    <?php echo e(session('success_msg')); ?>

                </div>
            <?php endif; ?>

            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Klucz</th>
                        <th scope="col">Nazwa</th>
                        <th scope="col">Jednostka</th>
                        <th scope="col">Akcje</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <th scope="row"><?php echo e($attribute->id); ?></th>
                            <td><?php echo e($attribute->key); ?></td>
                            <td><?php echo e($attribute->name); ?></td>
                            <td><?php echo e($units[$attribute->unit]); ?></td>
                            <td>
                                <a
                                    href=<?php echo e(url('/dashboard/attribute/' . $attribute->id)); ?>

                                    class='btn btn-primary'
                                >Edytuj</a>

                                <a
                                    href=<?php echo e(url('/dashboard/attribute/' . $attribute->id . '/delete')); ?>

                                    class='btn btn-danger record-delete'
                                >Usuń</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <th scope='row' colspan='5' class='text-center'>Brak rekordów</th>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <?php echo e($attributes->appends(array(

            ))->links('pagination::bootstrap-4')); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $('.record-delete').on('click', function() {
            return confirm("Jesteś pewien?");
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH S:\courses\kasia_beska\a4\resources\views/dashboard/attributes/index.blade.php ENDPATH**/ ?>